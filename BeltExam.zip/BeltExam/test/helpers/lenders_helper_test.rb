require 'test_helper'

class LendersHelperTest < ActionView::TestCase
end
