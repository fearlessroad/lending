require 'test_helper'

class BorrowersHelperTest < ActionView::TestCase
end
