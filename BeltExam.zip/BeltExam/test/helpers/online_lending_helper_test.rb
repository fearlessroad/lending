require 'test_helper'

class OnlineLendingHelperTest < ActionView::TestCase
end
