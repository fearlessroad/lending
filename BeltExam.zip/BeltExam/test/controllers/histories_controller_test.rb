require 'test_helper'

class HistoriesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
