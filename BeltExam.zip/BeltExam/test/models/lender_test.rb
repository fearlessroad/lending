require 'test_helper'

class LenderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
